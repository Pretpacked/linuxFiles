from datetime import datetime

from selenium import webdriver
from selenium.webdriver.firefox.options import Options

from browser.settings import Educus, General


class Connect:
    driver = None
    school_dates = []
    school_times = ["8:45", "16:15"]
    school_breaks = [["10:45", "11:00"],
                     ["12:30", "13:00"],
                     ["14:30", "14:45"]]

    def __init__(self):
        if Educus.username != "" or Educus.password != "":
            try:
                start_count = datetime.now()

                options = Options()
                # Turning headless browser on/off
                if General.DEBUG is False:
                    options.headless = True

                # Starting the browser
                self.driver = webdriver.Firefox(options=options, executable_path=r'/usr/bin/geckodriver')
                self.driver.get("https://login.educus.nl/")

                # Select school for login into
                self.driver.find_element_by_id("txtScholenZoekVeld").send_keys(Educus.school)
                self.driver.find_element_by_xpath("//a[contains(text(), '{}')]".format(Educus.school)).click()

                # Login user into educus
                self.driver.find_element_by_id('id6').send_keys(Educus.username)
                self.driver.find_element_by_id('id7').send_keys(Educus.password)
                self.driver.find_element_by_id('id4').click()

            except Exception as e:
                print("Something went wrong please try again.")
                self.driver.quit()

    def agenda(self, weeknumber=datetime.now().isocalendar()[1]):
        # Change page to agenda page for exporting times
        self.driver.find_element_by_xpath('//a[@title="Agenda"]').click()

        # Change the page to list view
        #FIXME: Might given and error if language isn't Dutch, haven't tested it.
        self.driver.find_element_by_xpath("//a[contains(text(), 'Lijst')]").click()

        current_weeknumber = datetime.now().isocalendar()[1]

        # Check if todays week number is the same, if it isn't check all
        # week until that given week number has been reached
        if weeknumber != current_weeknumber:
            for x in range(weeknumber - current_weeknumber + 1):
                try:
                    self.driver.find_element_by_class_name("page-is-empty")
                    self.school_dates.append({"mo": None, "tu": None, "we": None, "th": None, "fr": None,
                                              "week_information": {"weeknumber": current_weeknumber + x,
                                                                   "week_date_start": datetime.fromisocalendar(
                                                                       2020, current_weeknumber + x, 1),
                                                                   "week_date_end": datetime.fromisocalendar(
                                                                       2020, current_weeknumber + x, 7)}})
                except:
                    information = self.driver.find_elements_by_class_name("agenda-class")
                    times = self.driver.find_elements_by_class_name("agenda-item")
                    for number, elem in enumerate(information):
                        self.agenda_disecting_day(times[number].text,
                                                  elem.text)
                self.agenda_next()
        #return self.school_dates

    def agenda_disecting_day(self, times, text):
        for time in times.split("-"):
            pass

        text_split = text.split(" - ")
    def agenda_next(self):
        self.driver.find_element_by_class_name("time-filter--right").click()

    def quit(self):
        self.driver.quit()