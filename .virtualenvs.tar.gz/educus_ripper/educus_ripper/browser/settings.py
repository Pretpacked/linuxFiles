class General:
    DEBUG = True


class Educus:
    username = "73665"
    password = "Ricardoa123@"
    school = "ROC Ter AA"
