from browser import educus

educus = educus.Connect()
print(educus.agenda(10))

educus.quit()