import os
import getpass
import datetime
import json


class File_Clean_Up():

    # TODO: moving this to a dedicated file, this will
    # make it so that the program auto paths can add.
    file_locations = {
        "search_locations": {
            "/Documents/", "/Documents/", "/Videos/",
            "/Pictures/", "/Downloads/", "/Music/", "/"
        },
        "store_locations": [
            "/Documents/zip/", "/Documents/log/", "/Documents/txt/",
            "/Videos/www/", "/Music/www/", "/Pictures/www/",
            "/Documents/unidentified/"
        ],
        "ignore_list": [
            "/.Xdefault", "/.xinitrc", "/.bash_profile",
            "/.gitconfig", "/www/"
        ],
        "log_file_location": "data/log/",
        "home_location": "/home/{}".format(getpass.getuser()),

    }
    log = []
    add_dir = []
    move_files = []

    # will add the new found dir to the array so
    # the user can add it if wanted.
    def check_dir(self, path, _file):
        for location in self. file_locations["search_locations"]:
            if "/{}/".format(_file) == location:
                return self.add_dir.extend([{
                    "file_name": _file,
                    "path": "{}{}".format(path, _file),
                    "reason": "New directory."
                }])
        return self.add_dir.extend([{
            "path": "{}{}/".format(path, _file),
            "store_path": "{}".format(_file)
        }])

    # checks if the file isn't on the ignore file,
    # if so add log. otherwish add to the move_files.
    def check_file(self, path, _file):
        for ignore_file in self.file_locations["ignore_list"]:
            print("IGNORE", ignore_file, _file)
            if ignore_file == _file or ignore_file == "/{}/".format(_file):
                return self.log.extend([{
                    "file_name": _file,
                    "path": "{}{}".format(path, _file),
                    "reason": "File found in the ignore list."
                }])
        print(path, _file)
        pass

    # check if the given paths that where given exist,
    # this will create them if path doesn't exist.
    def check_exist_paths(self, paths):
        home_path = self.file_locations["home_location"]

        #print("Checking directories:")
        for path in paths:
            if os.path.exists(home_path + path):
                pass
                #print("VALID!\t{}".format(home_path + path))
            else:
                os.mkdir(home_path + path)
                #print("INVALID!\t{}".format(home_path + path))
        #print("")

    # function will be triggered when the program is
    # finished. 
    def check_finished(self):
        pass

    # runs the defualt program.
    def run(self):

        self.check_exist_paths(self.file_locations["search_locations"])
        self.check_exist_paths(self.file_locations["store_locations"])

        home_path = self.file_locations["home_location"]
        paths = self.file_locations["search_locations"]
        for path in paths:
            for _file in os.listdir(home_path + path):
                #print(home_path + path, _file)
                if os.path.isfile("{}{}".format(home_path + path, _file)):
                    self.check_file(home_path + path, _file)
                else:
                    self.check_dir(home_path + path, _file)



check=File_Clean_Up()
check.run()
print(check.log)