#!/bin/bash

# prints the input
function spotify() {
    python /home/ricardo/.virtualenvs/spotify_commands/spotify_commands/connect.pu $1 $2 $3
}
