#!/usr/bin/env python
# !/bin/sh

import requests as r
import webbrowser
import string
import random
import base64
from urllib.parse import urlencode
from datetime import datetime, timedelta
import sys
from pathlib import Path
import json
import time

# turning debug mode on or off
DEBUG = False


# for giving away state id's and checking them later.
class State:
    state = ''

    def __init__(self):
        self.state = self.randomString()

    def check(self, state):
        if state != self.state:
            return False

    def randomString(self, stringLength=11):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(stringLength))


# class for handeling connections.
class Connect:
    client_id = "bd8624254a7a47108a7f86f45f7cd1d6"
    client_secret = "9ecd895419d14975af28c800793daa3d"

    user_data = {
        'refresh_token': '',
        'access_token': '',
        'expires_in': {
            'request_time': '',
            'request_new': '',
            'time_table': ''
        },
        'scope': [],
        'refresh_file_location': str(Path.home())+'/Documents/.refresh_token'
    }

    def __init__(self):
        try:
            self.user_data["refresh_token"] = open(
                self.user_data["refresh_file_location"], "r").read()
        except IOError:
            self.login()

    def login(self):
        state = State()

        # recieving the authorization code.
        url = "https://accounts.spotify.com/authorize?{}&state={}".format(
            urlencode({
                'client_id': 'bd8624254a7a47108a7f86f45f7cd1d6',
                'scope[]': [
                    'ugc-image-upload', 'user-read-playback-state',
                    'user-modify-playback-state',
                    'user-read-currently-playing',
                    'streaming', 'app-remote-control', 'user-read-email',
                    'user-read-private', 'playlist-read-collaborative',
                    'playlist-modify-public', 'playlist-read-private',
                    'playlist-modify-private', 'user-library-modify',
                    'user-library-read', 'user-top-read',
                    'user-read-recently-played',
                    'user-follow-read', 'user-follow-modify'],
                'redirect_uri': 'https://localhost/',
                'response_type': 'code'
            }), state.state)
        webbrowser.open(url, new=2)

        user_url = input('Paste the full url link!\n')

        try:
            # check if the state hasn't changed, if so raise error.
            if state.check(user_url.split('&state=')[1]) is False:
                raise ValueError('The saved state doesn"t match the recieved '
                                 + 'state!\nState protects against attacks'
                                 + ' such as cross-site request forgery! See '
                                 + 'RFC-6749.')
            code = user_url.split('?code=')[1].split('&state=')[0]
        except Exception as error:
            input(' - {}\nSOMETHING WENT WRONG! press enter to retry:'.format(
                error))
            self.login()

        # base64 encodeing for the client/secret id.
        client_decode = '{}:{}'.format(self.client_id, self.client_secret)
        client_encode = base64.b64encode(client_decode.encode('utf-8'))
        client_encode = str(client_encode, 'utf-8')

        # recieve the refresh token and access tokens.
        url = 'https://accounts.spotify.com/api/token?'

        recieve = r.post(url, data={
                'grant_type': 'authorization_code', 'code': code,
                'redirect_uri': 'https://localhost/',
                'client_secret': '9ecd895419d14975af28c800793daa3d',
                'client_id': 'bd8624254a7a47108a7f86f45f7cd1d6'
                })
        recieve = recieve.json()

        self.user_data["refresh_token"] = recieve["refresh_token"]
        self.user_data["access_token"] = recieve["access_token"]

        self.user_data["request_time"] = datetime.now()
        self.user_data["request_new"] = datetime.now() + timedelta(
            seconds=recieve["expires_in"])
        self.user_data["time_table"] = recieve["expires_in"]

        self.user_data["scope"] = recieve["scope"]

        self.write_to_file(recieve["refresh_token"])

    def get_accesstokken(self):
        if (not self.user_data["expires_in"]["time_table"] or
                datetime.now() >= self.user_data["expires_in"]["time_table"]):
            url = 'https://accounts.spotify.com/api/token?'

            recieve = r.post(url, data={
                    'grant_type': 'refresh_token',
                    'refresh_token': self.user_data["refresh_token"],
                    'client_secret': '9ecd895419d14975af28c800793daa3d',
                    'client_id': 'bd8624254a7a47108a7f86f45f7cd1d6'
                    })

            recieve = recieve.json()

            self.user_data["access_token"] = recieve["access_token"]
            self.user_data["scope"] = recieve["scope"]

            self.user_data["request_time"] = datetime.now()
            self.user_data["request_new"] = datetime.now() + timedelta(
                seconds=recieve["expires_in"])
            self.user_data["time_table"] = recieve["expires_in"]

        return self.user_data["access_token"]

    # write user data to file.
    def write_to_file(self, data):
        f = open(self.user_data["refresh_file_location"], "w+")
        f.write(data)
        f.close()

    # TODO: make logout function
    def logout(self):
        pass


# class will handel the requests to the spotify REST API and spotify SDK
class Spotify:
    token = Connect()
    device_id = "83d5618cb1a65eb291c220b778d5fc8204b5d883"
    url = "https://api.spotify.com"

    def debug(self, output, type):
        if DEBUG is True:
            print("[", type, "]\n", output, "\n")

    def get(self, endpoint):
        response = r.get("{}{}".format(self.url, endpoint),
                         headers={"Authorization": "Bearer {}".format(
                                  self.token.get_accesstokken())}).text
        self.debug(response, "requests, GET, {}".format(endpoint))
        return response

    def put(self, endpoint, *args, **kwargs):
        param = kwargs.get('paramaters', {})
        data = kwargs.get('data', {})
        headers = {"Authorization": "Bearer {}".format(
                   self.token.get_accesstokken())}
        response = r.put("{}{}".format(self.url, endpoint),
                         headers=headers, json=param, data=data).text
        self.debug(response, "requests, PUT, {}".format(endpoint))
        return response

    def post(self, endpoint):
        response = r.post("{}{}".format(self.url, endpoint),
                          headers={"Authorization": "Bearer {}".format(
                                   self.token.get_accesstokken())}).text
        self.debug(response, "requests, POST, {}".format(endpoint))
        return response

    # Get a User's Available Devices.
    def available_devices(self):
        return self.get("/v1/me/player/devices")

    # Get the User's Currently Playing Track.
    def currently_playing_track(self):
        return self.get("/v1/me/player/currently-playing")

    # Get Information About The User's Current Playback.
    def current_playback(self):
        return self.get("/v1/me/player")

    # Pause a User's Playback.
    def pause(self, device=None):
        return self.put("/v1/me/player/pause")

    # Start/Resume a User's Playback.
    # context_uri = valid context are albums, artist and playlist.
    # position_ms = play position in ms.
    def play(self, device_id=None, context_uri=None, position_ms=None):
        data = {}
        paramaters = {}

        if device_id is not None:
            paramaters.update({"device_id": device_id})

        if context_uri is not None:
            data.update({"context_uri": context_uri})

        if position_ms is not None:
            data.update({"position_ms": position_ms})

        # TODO: make it so that if nothing is playing that the last song
        # that has been selected starts.

        if device_id == "webapp":
            paramaters.update({"device_id": self.device_id})
            for x in json.loads(self.available_devices())["devices"]:
                if x["name"] == "Supreme Broccoli":
                    return self.put("/v1/me/player/play", data=data,
                                    paramaters=paramaters)
            self.open_webapp()
            return self.put("/v1/me/player/play", data=data,
                            paramaters=paramaters)
        elif device_id == "phone":
            paramaters.update({"device_id": self.device_id})
            for x in json.loads(self.available_devices())["devices"]:
                if x["name"] == "OnePlus 7 Pro":
                    return self.put("/v1/me/player/play", data=data,
                                    paramaters=paramaters)
            self.open_webapp()
            return self.put("/v1/me/player/play", data=data,
                            paramaters=paramaters)
        return self.put("/v1/me/player/play", data=data,
                        paramaters=paramaters)

    # Skip User's Playback To Next Track.
    def skip(self):
        self.post("/v1/me/player/next")
        current = json.loads(self.current_playback())
        print(current["item"]["artists"][0]["name"],
              "-", current["item"]["name"])

    # Skip User's Playback To Previous Track.
    def previous(self):
        self.post("/v1/me/player/previous")
        current = json.loads(self.current_playback())
        print(current["item"]["artists"][0]["name"],
              "-", current["item"]["name"])

    """def shuffle(self, state):
        return self.put("/v1/me/player/seek", data={
            'state': state
        })"""

    def info(self):
        print("Arthur:\tRicardo")
        print("Version: 0.0.1")

    # Shows the help page with all the commands and what they are used for.
    def help(self):
        print("spotify [command]")
        print("\tavailable\tGet a User's Available Devices.")
        print("\tcurrently\tGet the User's Currently Playing Track.")
        print("\tnow\t\tGet Information About The User's Current Playback.")
        print("\tpause\t\tPause a User's Playback.")
        print("\tplay\t\tStart/Resume a User's Playback.")
        print("\tskip\t\tSkip User's Playback To Next Track.")
        print("\tprevious\tSkip User's Playback To Previous Track.")
        print("\tstatus\t\tShow status of user in a while loop.")

    # TODO: Create status bar for spotify.
    def status(self):
        while True:
            time.sleep(1)
            current = json.loads(self.current_playback())

    # FIXME: Fix problem of url not loading into the browser.
    def open_webapp(self):
        for x in json.loads(self.available_devices())["devices"]:
            if x["name"] == "Supreme Broccoli":
                return
        print("Opening webapp")
        webbrowser.open("file:///home/ricardo/.virtualenvs/spotify_commands/"
                        + "spotify_commands/index.html?"
                        + "refresh_token={}".format(
                            self.token.user_data["refresh_token"]), new=2)

    # TODO: make it so the program checks if its online.
    # TODO: check if playing if so pause also otherway around.
    def quick_play_pause():
        pass


# command handeler for bash to spotify code.
class Commands:
    def __init__(self):
        if len(sys.argv) <= 1:
            return Spotify().info()

        sys.argv.pop(0)  # remove first entity, because its location of file.
        self.command_check(sys.argv[0])

    def command_check(self, command):
        commands = {"avaialable": "available_devices",
                    "currently": "currently_playing_track",
                    "now": "current_playback",
                    "pause": "pause",
                    "play": "play",
                    "skip": "skip",
                    "previous": "previous",
                    "help": "help",
                    "status": "status",
                    "webapp": "open_webapp"}

        shortkey_commands = {
            "h": "help",
            "pp": "quick_play_pause"
        }

        for key, value in commands.items():
            if command == key:
                if len(sys.argv) > 1:
                    sys.argv.remove(key)
                    return getattr(Spotify(), value)(device_id=sys.argv[0])
                return getattr(Spotify(), value)()

        for key, value in shortkey_commands.items():
            if command == key:
                return getattr(Spotify(), value)()

        print("spotify:", command, "command not found. try spotify help.")


if __name__ == "__main__":
    x = Commands()
